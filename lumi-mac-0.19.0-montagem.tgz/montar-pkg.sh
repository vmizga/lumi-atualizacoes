#!/bin/bash
# Monta Lumi-<versão>.pkg (rode num Mac). Uso: bash montar-pkg.sh <pasta com o whisper-cli do Mac>
set -euo pipefail
cd "$(dirname "$0")"
VER=$(python3 -c 'import json;print(json.load(open("lumi-stage/app/package.json"))["version"])')
W="${1:?pasta do whisper-cli do Mac}"
[ -x "$W/whisper-cli" ] || { echo "whisper-cli não está em $W"; exit 1; }
if otool -L "$W/whisper-cli" | tail -n +2 | grep -v -E '^\s+(/usr/lib/|/System/)'; then
  echo "ERRO: whisper-cli depende das bibliotecas acima; compile com -DBUILD_SHARED_LIBS=OFF"; exit 1
fi
T=$(mktemp -d); R="$T/root"
DEST="$R/Library/Application Support/Blackmagic Design/DaVinci Resolve/Workflow Integration Plugins/com.plugindavinci.legendas"
mkdir -p "$DEST/vendor/whisper.cpp/Release"
cp -R lumi-stage/. "$DEST/"
cp "$W/whisper-cli" "$DEST/vendor/whisper.cpp/Release/"
xattr -cr "$R"
pkgbuild --root "$R" --identifier com.gazzfilmes.lumi --version "$VER" --scripts scripts --install-location / "$T/lumi-comp.pkg"
cat > "$T/dist.xml" <<X
<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
  <title>Lumi $VER</title>
  <options customize="never" require-scripts="false" hostArchitectures="arm64"/>
  <domains enable_localSystem="true"/>
  <choices-outline><line choice="lumi"/></choices-outline>
  <choice id="lumi" title="Lumi"><pkg-ref id="com.gazzfilmes.lumi"/></choice>
  <pkg-ref id="com.gazzfilmes.lumi" version="$VER">lumi-comp.pkg</pkg-ref>
</installer-gui-script>
X
productbuild --distribution "$T/dist.xml" --package-path "$T" "Lumi-$VER.pkg"
echo "ok  $(pwd)/Lumi-$VER.pkg"
